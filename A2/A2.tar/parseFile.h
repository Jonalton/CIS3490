#include <stdio.h>
#include <stdlib.h>

int* parseFile1(int *n, char* filename);
double** parseFile2(int *n, char* filename);
